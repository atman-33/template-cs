﻿using Oracle.ManagedDataAccess.Client;
using System.Data;

namespace Template.Infrastruture.Oracle
{
    //// 【OracleParameterの注意点】
    //// SQL文中のパラメータ記載方法 => :+文字列
    //// Prameter生成方法 => new OracleParameter("文字列", 置き換えする値)

    internal class OracleOdpDao
    {
        OracleConnection _connection;

        public OracleOdpDao(string user, string password, string dataSource)
        {
            string connectionString = "User Id=" + user + ";Password=" + password + ";Data Source=" + dataSource;
            _connection = new OracleConnection(connectionString);

            try
            {
                _connection.Open();
            }
            catch (Exception e)
            {
                throw new Exception(e.ToString());
            }
        }
        public void Close()
        {
            _connection.Close();
            _connection.Dispose();
        }

        public void ExecuteNonQuery(string sql)
        {
            OracleCommand command = new OracleCommand(sql, _connection);
            command.ExecuteNonQuery();
        }

        public OracleDataAdapter ExecuteQueryAdapter(string sql)
        {
            OracleDataAdapter adapter = new OracleDataAdapter(sql, _connection);
            return adapter;
        }

        public OracleDataReader ExecuteQueryReader(string sql)
        {
            OracleCommand command = new OracleCommand(sql, _connection);
            OracleDataReader reader = command.ExecuteReader();

            return reader;
        }

        public IReadOnlyList<T> Query<T>(
            string sql,
            Func<OracleDataReader, T> createEntity)
        {
            return Query<T>(sql, null, createEntity);
        }

        public IReadOnlyList<T> Query<T>(
            string sql,
            OracleParameter[]? parameters,
            Func<OracleDataReader, T> createEntity)
        {
            var result = new List<T>();

            using (var command = new OracleCommand(sql, _connection))
            {
                if (parameters != null)
                {
                    command.Parameters.AddRange(parameters);
                }

                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        result.Add(createEntity(reader));
                    }
                }
            }
            return result.AsReadOnly();
        }

        public T QuerySingle<T>(
            string sql,
            Func<OracleDataReader, T> createEntity,
            T nullEntity)
        {
            return QuerySingle<T>(sql, null, createEntity, nullEntity);
        }

        /// <summary>
        /// クエリを実行し、単体レコードを取得（パラメータ変換有り）
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="sql"></param>
        /// <param name="parameters"></param>
        /// <param name="createEntity"></param>
        /// <param name="nullEntity"></param>
        /// <returns></returns>
        public T QuerySingle<T>(
            string sql,
            OracleParameter[]? parameters,
            Func<OracleDataReader, T> createEntity,
            T nullEntity)
        {
            using (var command = new OracleCommand(sql, _connection))
            {
                if (parameters != null)
                {
                    command.Parameters.AddRange(parameters);
                }

                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        return createEntity(reader);
                    }
                }
            }
            return nullEntity;
        }

        public void Execute(
            string insert,
            string update,
            OracleParameter[] parameters)
        {
            using (var command = new OracleCommand(update, _connection))
            using (OracleTransaction transaction = _connection.BeginTransaction(IsolationLevel.ReadCommitted))
            {
                command.Transaction = transaction;
                command.BindByName = true;
                try
                {
                    if (parameters != null)
                    {
                        command.Parameters.AddRange(parameters);
                    }

                    if (command.ExecuteNonQuery() < 1)
                    {
                        command.CommandText = insert;
                        command.ExecuteNonQuery();
                    }

                    transaction.Commit();
                }
                catch(DataException e)
                {
                    transaction.Rollback();
                    Console.WriteLine(e.ToString());
                }
            }
        }

        public void Execute(
            string sql,
            OracleParameter[] parameters)
        {
            using (var command = new OracleCommand(sql, _connection))
            using (OracleTransaction transaction = _connection.BeginTransaction(IsolationLevel.ReadCommitted))
            {
                command.Transaction = transaction;

                try
                {
                    if (parameters != null)
                    {
                        command.Parameters.AddRange(parameters);
                    }

                    command.ExecuteNonQuery();
                    transaction.Commit();
                }
                catch (DataException e)
                {
                    transaction.Rollback();
                    Console.WriteLine(e.ToString());
                }
            }
        }
    }
}
