﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Template.Domain.Entities;

namespace Template.Domain.Repositories
{
    /// <summary>
    /// ISampleMasterRepository
    /// </summary>
    public interface ISampleTableRepository
    {
        IReadOnlyList<SampleTableEntity> GetData();
        IReadOnlyList<SampleTableEntity> GetData2();

        void Save(SampleTableEntity enitity);
        void Save2(SampleTableEntity enitity);
        void Delete(SampleTableEntity enitity);
    }
}
