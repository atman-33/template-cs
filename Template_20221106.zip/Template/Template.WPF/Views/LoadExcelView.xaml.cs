﻿using System.Windows.Controls;

namespace Template.WPF.Views
{
    /// <summary>
    /// Interaction logic for LoadExcelView
    /// </summary>
    public partial class LoadExcelView : UserControl
    {
        public LoadExcelView()
        {
            InitializeComponent();
        }
    }
}
