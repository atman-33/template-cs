﻿using System.Windows.Controls;

namespace Template.WPF.Views
{
    /// <summary>
    /// Interaction logic for LoadCsvView
    /// </summary>
    public partial class LoadCsvView : UserControl
    {
        public LoadCsvView()
        {
            InitializeComponent();
        }
    }
}
