﻿using System.Windows.Controls;

namespace Template.WPF.Views
{
    /// <summary>
    /// Interaction logic for AutoUpdateDisplayView
    /// </summary>
    public partial class AutoUpdateDisplayView : UserControl
    {
        public AutoUpdateDisplayView()
        {
            InitializeComponent();
        }
    }
}
