﻿using Prism.Commands;
using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Template.WPF.ViewModels
{
    public class SettingsViewModel : BindableBase
    {
        public SettingsViewModel()
        {

        }
    }
}
