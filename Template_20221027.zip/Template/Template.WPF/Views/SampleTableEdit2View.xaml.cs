﻿using System.Windows.Controls;

namespace Template.WPF.Views
{
    /// <summary>
    /// Interaction logic for SampleTableEdit2View
    /// </summary>
    public partial class SampleTableEdit2View : UserControl
    {
        public SampleTableEdit2View()
        {
            InitializeComponent();
        }

        //private void UserControl_Error(object sender, ValidationErrorEventArgs e)
        //{

        //}
    }
}
