﻿using System.Windows.Controls;

namespace Template.WPF.Views
{
    /// <summary>
    /// Interaction logic for SampleNavigationView
    /// </summary>
    public partial class SampleNavigationView : UserControl
    {
        public SampleNavigationView()
        {
            InitializeComponent();
        }
    }
}
