﻿using System.Windows.Controls;

namespace Template.WPF.Views
{
    /// <summary>
    /// Interaction logic for SampleTableEdit3View
    /// </summary>
    public partial class SampleTableEdit3View : UserControl
    {
        public SampleTableEdit3View()
        {
            InitializeComponent();
        }
    }
}
