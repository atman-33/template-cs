﻿using Prism.Commands;
using Prism.Mvvm;
using Prism.Regions;
using Prism.Services.Dialogs;
using Template.WPF.Views;

namespace Template.WPF.ViewModels
{
    public class MainWindowViewModel : BindableBase
    {
        private IRegionManager _regionManager;  //// 画面遷移（ナビゲーション）
        private IDialogService _dialogService;  //// 画面遷移（ダイアログ）

        private string _title = "TOP画面";
        public string Title
        {
            get { return _title; }
            set { SetProperty(ref _title, value); }
        }

        public MainWindowViewModel(IRegionManager regionManager, IDialogService dialogService)
        {
            //// 画面遷移用（ナビゲーション）
            _regionManager = regionManager;

            //// 画面遷移用（ダイアログ）
            _dialogService = dialogService;

            SampleNavigationViewButton = new DelegateCommand(SampleNavigationViewButtonExecute);
            SampleTableEditButton = new DelegateCommand(SampleTableEditButtonExecute);
            SampleTableEdit2Button = new DelegateCommand(SampleTableEdit2ButtonExecute);
            SampleTableEdit3Button = new DelegateCommand(SampleTableEdit3ButtonExecute);
        }

        //// イベント処理用デリゲートコマンド
        public DelegateCommand SampleNavigationViewButton { get; }
        public DelegateCommand SampleTableEditButton { get; }
        public DelegateCommand SampleTableEdit2Button { get; }
        public DelegateCommand SampleTableEdit3Button { get; }

        private void SampleNavigationViewButtonExecute()
        {
            //// 画面遷移処理（ナビゲーション）
            _regionManager.RequestNavigate("ContentRegion", nameof(SampleNavigationView));
        }

        private void SampleTableEditButtonExecute()
        {
            //// 画面遷移処理（ダイアログ）
            _dialogService.ShowDialog(nameof(SampleTableEdit1View), null, null);
        }

        private void SampleTableEdit2ButtonExecute()
        {
            //// 画面遷移処理（ダイアログ）
            _dialogService.ShowDialog(nameof(SampleTableEdit2View), null, null);

        }
        private void SampleTableEdit3ButtonExecute()
        {
            //// 画面遷移処理（ダイアログ）
            _dialogService.ShowDialog(nameof(SampleTableEdit3View), null, null);

        }

    }
}
