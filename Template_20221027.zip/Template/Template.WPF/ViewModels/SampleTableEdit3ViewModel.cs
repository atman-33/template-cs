﻿using Prism.Mvvm;
using Prism.Services.Dialogs;
using System;
using System.Collections.ObjectModel;
using System.Data;
using Template.Domain.Entities;
using Template.Domain.Repositories;
using Template.Infrastruture;

namespace Template.WPF.ViewModels
{
    public class SampleTableEdit3ViewModel : BindableBase, IDialogAware
    {
        //// 外部接触Repository
        private ISampleItemTimeRepository _sampleItemTimeRepository;


        public SampleTableEdit3ViewModel()
        {
            //// Factories経由で作成したRepositoryを、プライベート変数に格納
            _sampleItemTimeRepository = Factories.CreateSampleItemTime();

            //// サンプル項目時間のデータを取得
            ObservableCollection<SampleItemTimeEntity> sampleItemTimeEntities = new ObservableCollection<SampleItemTimeEntity>();
            foreach (var entity in _sampleItemTimeRepository.GetData())
            {
                sampleItemTimeEntities.Add(entity);
            }
            _sampleItemTimeRecords = new SampleTableEdit3ViewModelSampleItemTime(sampleItemTimeEntities).DataViewItemSource;
        }

        private DataView _sampleItemTimeRecords;
        public DataView SampleItemTimeRecords
        {
            get { return _sampleItemTimeRecords; }
            set
            {
                SetProperty(ref _sampleItemTimeRecords, value);
            }
        }

        //// ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- 
        //// IDialogAware 実装関連
        //// ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- 
        public string Title => "DataGrid編集";

        public event Action<IDialogResult> RequestClose;

        public bool CanCloseDialog()
        {
            return true;
        }

        public void OnDialogClosed()
        {
        }

        public void OnDialogOpened(IDialogParameters parameters)
        {
        }
    }
}
