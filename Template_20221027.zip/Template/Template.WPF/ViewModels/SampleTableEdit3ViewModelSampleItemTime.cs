﻿using Prism.Mvvm;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using Template.Domain.Entities;
using Template.Domain.Modules.Helpers;

namespace Template.WPF.ViewModels
{
    public class SampleTableEdit3ViewModelSampleItemTime : BindableBase
    {
        public SampleTableEdit3ViewModelSampleItemTime(ObservableCollection<SampleItemTimeEntity> sampleItemTimeEntities)
        {
            DataViewItemSource = DataViewHelper.CreatePivotTable<SampleItemTimeEntity, float>(
                "Name",
                sampleItemTimeEntities.ToLookup(o => o.SampleName.Value),
                (i) =>
                {
                    return i.SampleItem.Value;
                },
                (i) =>
                {
                    return i.SampleTime.Value;
                });
        }

        public DataView DataViewItemSource { get; set; }
    }
}
