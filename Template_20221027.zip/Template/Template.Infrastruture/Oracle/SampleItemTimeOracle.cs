﻿using Template.Domain.Entities;
using Template.Domain.Repositories;

namespace Template.Infrastruture.Oracle
{
    internal class SampleItemTimeOracle : ISampleItemTimeRepository
    {
        public IReadOnlyList<SampleItemTimeEntity> GetData()
        {
            throw new NotImplementedException();
        }
    }
}
