﻿using Template.Domain.Entities;
using Template.Domain.Repositories;
using Template.Domain.SQLite;

namespace Template.Infrastruture.SQLite
{
    internal class SampleItemTimeFake : ISampleItemTimeRepository
    {
        public IReadOnlyList<SampleItemTimeEntity> GetData()
        {
            string sql = @"
SELECT
  sample_name,
  sample_item,
  sample_time
FROM
  sample_item_time
";

            return SQLiteHelper.Query(sql,
                reader =>
                {
                    return new SampleItemTimeEntity(
                        Convert.ToString(reader["sample_name"]),
                        Convert.ToString(reader["sample_item"]),
                        Convert.ToSingle(reader["sample_time"]));
                });
        }
    }
}
