﻿using Prism.Commands;
using Prism.Mvvm;
using Prism.Regions;
using Prism.Services.Dialogs;
using Template.WPF.Views;

namespace Template.WPF.ViewModels
{
    public class MainWindowViewModel : BindableBase
    {
        private IRegionManager _regionManager;  //// 画面遷移（ナビゲーション）

        private string _title = "サンプルアプリ";

        public MainWindowViewModel(IRegionManager regionManager)
        {
            //// 画面遷移用（ナビゲーション）
            _regionManager = regionManager;

            //// DelegateCommandメソッドを登録
            WindowContentRendered = new DelegateCommand(WindowContentRenderedExecute);
            HomeViewButton = new DelegateCommand(HomeViewButtonExecute);
            SampleNavigationViewButton = new DelegateCommand(SampleNavigationViewButtonExecute);
        }

        public string Title
        {
            get { return _title; }
            set { SetProperty(ref _title, value); }
        }

        //// ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- 
        //// 各オブジェクトのデータバインド
        //// ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- 

        /// <summary>
        /// メイン画面上部のタイトル
        /// </summary>
        private string _contentTitle = "サンプルタイトル";
        public string ContentTitle
        {
            get { return _contentTitle; }
            set { SetProperty(ref _contentTitle, value); }
        }

        //// ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- 
        //// DelegateCommand 関連（パラメータパスを受ける場合は型指定が必要）
        //// ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- 

        /// <summary>
        /// ウィンドウのコンテンツが描画された後の処理
        /// </summary>
        public DelegateCommand WindowContentRendered { get; }

        private void WindowContentRenderedExecute()
        {
            ContentTitle = "ホーム画面";
            _regionManager.RequestNavigate("ContentRegion", nameof(HomeView));
        }

        public DelegateCommand HomeViewButton { get; }

        private void HomeViewButtonExecute()
        {
            ContentTitle = "ホーム画面";

            //// 画面遷移処理（ナビゲーション）
            _regionManager.RequestNavigate("ContentRegion", nameof(HomeView));
        }

        public DelegateCommand SampleNavigationViewButton { get; }

        private void SampleNavigationViewButtonExecute()
        {
            ContentTitle = "DataGridテスト";

            //// 画面遷移処理（ナビゲーション）
            _regionManager.RequestNavigate("ContentRegion", nameof(SampleNavigationView));
        }
    }
}
