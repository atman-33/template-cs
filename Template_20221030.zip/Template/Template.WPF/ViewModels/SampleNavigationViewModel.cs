﻿using Prism.Commands;
using Prism.Mvvm;
using Prism.Services.Dialogs;
using System;
using System.Collections.Generic;
using System.Linq;
using Template.WPF.Views;

namespace Template.WPF.ViewModels
{
    public class SampleNavigationViewModel : BindableBase
    {
        private IDialogService _dialogService;  //// 画面遷移（ダイアログ）

        public SampleNavigationViewModel(IDialogService dialogService)
        {
            //// 画面遷移用（ダイアログ）
            _dialogService = dialogService;

            SampleTableEditButtonCommand = new DelegateCommand(SampleTableEditButtonCommandExecute);
            SampleTableEdit2ButtonCommand = new DelegateCommand(SampleTableEdit2ButtonCommandExecute);
            SampleTableEdit3ButtonCommand = new DelegateCommand(SampleTableEdit3ButtonCommandExecute);
        }

        public DelegateCommand SampleTableEditButtonCommand { get; }
        public DelegateCommand SampleTableEdit2ButtonCommand { get; }
        public DelegateCommand SampleTableEdit3ButtonCommand { get; }

        private void SampleTableEditButtonCommandExecute()
        {
            //// 画面遷移処理（ダイアログ）
            _dialogService.ShowDialog(nameof(SampleTableEdit1View), null, null);
        }

        private void SampleTableEdit2ButtonCommandExecute()
        {
            //// 画面遷移処理（ダイアログ）
            _dialogService.ShowDialog(nameof(SampleTableEdit2View), null, null);

        }
        private void SampleTableEdit3ButtonCommandExecute()
        {
            //// 画面遷移処理（ダイアログ）
            _dialogService.ShowDialog(nameof(SampleTableEdit3View), null, null);
        }
    }
}
